SC_glm=function(mu_update,mu_init,tol=0.001){

  mu_inl2=sum(mu_init^2)
  if(mu_inl2==0){
    res=sum((mu_update-mu_init)^2)
  } else{
    res=sum((mu_update-mu_init)^2)/mu_inl2
  }
  return(res<=tol)
}

svd_d=function(X,p1,p2){
  X_svd=svd(X,p1,p2)
  return(sum(X_svd$d))
}

SVS=function(Y,n,p,lambda){
  Y_svd=svd(Y,nu=n,nv=p)
  sv_lambda=Y_svd$d-lambda
  Sigma=matrix(0,n,p)
  diag(Sigma)=sv_lambda*(sv_lambda>0)

  return(Y_svd$u%*%Sigma%*%t(Y_svd$v))
}

#theta=theta_init;delta=delta_init;gamma=gamma_init;mu=mu_init;v=v_init
Loss_Sm_glm=function(X,y,theta,theta_m,delta,delta_m,gamma,v,mu,K,nk,p1,p2,lambda1,lambda2,tau,alpha,rho1,rho2){

  Loss=0;p12=p1*p2
  for(k in 1:K){

    Gradient_sum=matrix(0,p1,p2);Hessian_sum=matrix(0,p12,p12)
    for(i in 1:nk[k]){

      exp_eta=exp(sum(X[[k]][,,i]*theta_m[,,k]))
      Gradient_sum=Gradient_sum+(exp_eta/(1+exp_eta)-y[[k]][i])*X[[k]][,,i]
      Hessian_sum=Hessian_sum+c(X[[k]][,,i])%*%t(c(X[[k]][,,i]))*exp_eta/((1+exp_eta)^2)
    }

    Loss=Loss+(sum(Gradient_sum*gamma[,,k])+t(c(gamma[,,k]))%*%Hessian_sum%*%c(gamma[,,k])/2)*alpha[k]+lambda1*nk[k]*svd_d(theta[,,k],p1,p2)+rho2/2*norm((gamma[,,k]-theta[,,k]+theta_m[,,k]+mu[,,k]),"F")^2-rho2/2*norm(mu[,,k],"F")^2
  }

  for(k in 1:(K-1)){
    delta_svd=svd_d(delta[,,k],p1,p2);delta_m_svd=svd_d(delta_m[,,k],p1,p2)
    Loss=Loss+lambda2*nk[k]*(delta_svd*(delta_m_svd<tau)+tau*(delta_m_svd>=tau))+rho1/2*norm((delta[,,k]-theta[,,k]+theta[,,K]+v[,,k]),"F")^2-rho1/2*norm(v[,,k],"F")^2
  }
  return(Loss)
}

#theta=theta_init;delta=delta_init;gamma=gamma_init;mu=mu_init;v=v_init
AD1_glm=function(theta,theta_m,delta,gamma,v,mu,K,nk,p1,p2,lambda1,rho1,rho2){

  theta_hat=array(0,c(p1,p2,K))
  rho12=rho1+rho2;rhoK12=(K-1)*rho1+rho2

  for(k in 1:(K-1)){

    Aug=rho1/rho12*(delta[,,k]+theta[,,K]+v[,,k])+rho2/rho12*(gamma[,,k]+theta_m[,,k]+mu[,,k])
    theta_hat[,,k]=SVS(Aug,p1,p2,(lambda1*nk[k]/rho12))
  }

  Aug=matrix(0,p1,p2)
  for(k in 1:(K-1)){
    Aug=Aug+(-delta[,,k]+theta_hat[,,k]-v[,,k])
  }
  Aug=(rho1*Aug+rho2*(gamma[,,K]+theta_m[,,K]+mu[,,K]))/rhoK12
  theta_hat[,,K]=SVS(Aug,p1,p2,nk[K]*lambda1/rhoK12)

  return(theta_hat)
}

AD2_glm=function(theta,delta_m,v,K,nk,p1,p2,lambda2,tau,rho1){

  delta_hat=delta_m

  for(k in 1:(K-1)){

    th_v=theta[,,k]-theta[,,K]-v[,,k]

    if(svd_d(delta_m[,,k],p1,p2)<tau){
      delta_hat[,,k]=SVS(th_v,p1,p2,lambda2*nk[k]/rho1)
    } else{
      delta_hat[,,k]=th_v
    }
  }
  return(delta_hat)
}

#theta=theta_update;mu=mu_init
AD3_glm=function(X,y,theta,theta_m,mu,K,nk,p1,p2,rho2,alpha){

  p12=p1*p2
  gamma_hat=theta
  for(k in 1:K){
    A=matrix(0,p12,p12)
    B1=rho2*(theta[,,k]-theta_m[,,k]-mu[,,k]);B2=matrix(0,p1,p2)
    for(i in 1:nk[k]){
      exp_eta=exp(sum(X[[k]][,,i]*theta_m[,,k]))
      B2=B2+(exp_eta/(1+exp_eta)-y[[k]][i])*X[[k]][,,i]
      A=A+alpha[k]*exp_eta/(1+exp_eta)^2*c(X[[k]][,,i])%*%t(c(X[[k]][,,i]))
    }

    B=B1-alpha[k]*B2
    A=A+diag(rho2,p12)
    inverse_try=try(solve(A),silent=TRUE)
    if(class(inverse_try)[1]=="try-error"){
      print("try-error")
      A_inverse=ginv(A)
    } else{
     A_inverse=inverse_try
    }
    gamma_hat[,,k]=A_inverse%*%c(B)
  }

  return(gamma_hat)
}

#theta_init=theta_ADMM_init;delta_init=delta_ADMM_init;gamma_init=gamma_ADMM_init;v_init=v_ADMM_init;mu_init=mu_ADMM_init
ADMM_glm=function(X,y,theta_init,theta_m,delta_init,delta_m,gamma_init,v_init,mu_init,
              K,nk,p1,p2,lambda1,lambda2,tau,alpha,rho1,rho2,tol_ADMM,maxit_ADMM){

  Loss_upper=c();l=1
  Loss_upper[l]=Loss_Sm_glm(X,y,theta_init,theta_m,delta_init,delta_m,gamma_init,v_init
                        ,mu_init,K,nk,p1,p2,lambda1,lambda2,tau,alpha,rho1,rho2)

  v_update=array(0,c(p1,p2,K-1));mu_update=array(0,c(p1,p2,K))
  while(TRUE){
      theta_update=AD1_glm(theta_init,theta_m,delta_init,gamma_init,v_init,mu_init
                       ,K,nk,p1,p2,lambda1,rho1,rho2)
      delta_update=AD2_glm(theta_update,delta_m,v_init,K,nk,p1,p2,lambda2,tau,rho1)
      gamma_update=AD3_glm(X,y,theta_update,theta_m,mu_init,K,nk,p1,p2,rho2,alpha)

      for(k in 1:(K-1)){
        v_update[,,k]=v_init[,,k]+delta_update[,,k]-theta_update[,,k]+theta_update[,,K]
      }

      for(k in 1:K){
        mu_update[,,k]=mu_init[,,k]+gamma_update[,,k]-theta_update[,,k]+theta_m[,,k]
      }

      Loss_upper[l+1]=Loss_Sm_glm(X,y,theta_update,theta_m,delta_update,delta_m,gamma_update,v_update
                              ,mu_update,K,nk,p1,p2,lambda1,lambda2,tau,alpha,rho1,rho2)

      if(l>maxit_ADMM){
        result=list()
        result$theta_update=theta_update
        result$delta_update=delta_update
        result$gamma_update=gamma_update
        result$v_update=v_update
        result$mu_update=mu_update
        result$Loss_ADMM=Loss_upper
        result$l=l
        return(result)
      }

      res1=array(0,c(p1,p2,K))
      res2=array(0,c(p1,p2,K-1))

      if(abs(Loss_upper[l+1]-Loss_upper[l])<tol_ADMM & SC_glm((gamma_update-theta_update+theta_m),res1,tol=tol_ADMM) & SC_glm(delta_update-theta_update[,,-K]+array(theta_update[,,K],c(p1,p2,K-1)),res2,tol=tol_ADMM)){
        result=list()
        result$theta_update=theta_update
        result$delta_update=delta_update
        result$gamma_update=gamma_update
        result$v_update=v_update
        result$mu_update=mu_update
        result$Loss_ADMM=Loss_upper
        result$l=l
        return(result)
      } else{
        theta_init=theta_update
        delta_init=delta_update
        gamma_init=gamma_update
        v_init=v_update
        mu_init=mu_update
        l=l+1
        #print(c(l,Loss_upper[l-1],round(sum((delta_update-theta_update[,,-K]+array(theta_update[,,K],c(p1,p2,K-1)))^2),2),round(sum((gamma_update-theta_update+theta_m)^2),2)))
        #print(c(l,Loss_upper[l-1]))
      }
  }
}

#alpha=NULL;theta_init=NULL;delta_init=NULL;tol_ADMM=1e-04;maxit_ADMM=3000;maxit_MM=10;tol_MM=0.1
TNPglm=function(X,y,lambda1,lambda2,tau,rho1=1,rho2=1,alpha=NULL,theta_init=NULL,delta_init=NULL,tol_ADMM=1e-04,maxit_ADMM=3000,tol_MM=0.1,maxit_MM=10){

  dimen=sapply(X,dim);K=p=0
  nk=dimen[3,];p1=dimen[1,1];p2=dimen[2,1];K=length(dimen[1,])

  if(is.null(alpha)){
    alpha=rep(1,K)
  }

  if(is.null(theta_init)){
    theta_init=array(0,dim=c(p1,p2,K))
    for (k in 1:K){
      fit=glm_FT(X[[k]],y[[k]],theta_P=NULL,lambda=lambda1,rho=1,alpha=NULL,delta_init=NULL,tol_ADMM=1e-04,maxit_ADMM=3000,maxit_MM=maxit_MM,tol_MM=tol_MM)
      theta_init[,,k] = fit$delta_update
    }
  }

  if(is.null(delta_init)){
    delta_init=array(0,dim=c(p1,p2,K-1))
    for(k in 1:(K-1)){
      delta_init[,,k]=theta_init[,,k]-theta_init[,,K]
    }
  }

  theta_m=theta_init;delta_m=delta_init
  theta_ADMM_init=theta_init;delta_ADMM_init=delta_init;gamma_ADMM_init=array(0,dim=c(p1,p2,K))
  v_ADMM_init=array(0,dim=c(p1,p2,K-1));mu_ADMM_init=array(0,dim=c(p1,p2,K))

  m=1
  Loss_theta=c()

  result=list();
  #resultfit=list()
  while(TRUE){
    fit=ADMM_glm(X=X,y=y,theta_init=theta_ADMM_init,theta_m=theta_m,delta_init=delta_ADMM_init,delta_m=delta_m,gamma_init=gamma_ADMM_init,v_init=v_ADMM_init,mu_init=mu_ADMM_init,K=K,nk=nk,p1=p1,p2=p2,lambda1=lambda1,lambda2=lambda2,tau=tau,alpha=alpha,rho1=rho1,rho2=rho2,tol_ADMM=tol_ADMM,maxit_ADMM=maxit_ADMM)
    theta_update=fit$theta_update;delta_update=fit$delta_update

    Loss_theta[m]=mean((theta_update-theta_m)^2)+mean((delta_update-delta_m)^2)
    #resultfit[[m]]=fit


    if(m>maxit_MM){
      result$theta_update=theta_update
      result$delta_update=delta_update
      #result$Loss_theta=Loss_theta
      #result$fit=resultfit
      result$m=m
      return(result)
    }

    #print(m)
    if(m>3){
      if(Loss_theta[m]<tol_MM){
        result$theta_update=theta_update
        result$delta_update=delta_update
        #result$Loss_theta=Loss_theta
        #result$fit=resultfit
        result$m=m
        return(result)
      } else{
        theta_m=theta_update
        delta_m=delta_update
        m=m+1
        #print(m)
      }
    } else{
      theta_m=theta_update
      delta_m=delta_update
      m=m+1
      #print(m)
    }
  }
}

#####Fine Tune Step####
Loss_Sm_glm_FT=function(X,y,theta_P,delta,delta_m,gamma,v,n,p1,p2,lambda,alpha,rho){
  Loss=0;p12=p1*p2;theta_delta=theta_P+delta_m

  Gradient_sum=matrix(0,p1,p2);Hessian_sum=matrix(0,p12,p12)
  for(i in 1:n){
    exp_eta=exp(sum(X[,,i]*(theta_delta)))
    Gradient_sum=Gradient_sum+(exp_eta/(1+exp_eta)-y[i])*X[,,i]
    Hessian_sum=Hessian_sum+c(X[,,i])%*%t(c(X[,,i]))*exp_eta/((1+exp_eta)^2)
  }

  Loss=Loss+(sum(Gradient_sum*gamma)+t(c(gamma))%*%Hessian_sum%*%c(gamma)/2)*alpha+lambda*svd_d(delta,p1,p2)+rho/2*norm((gamma-delta+delta_m+v),"F")^2-rho/2*norm(v,"F")^2
  return(Loss)
}

#gamma=gamma_init;v=v_init
AD1_glm_FT=function(delta_m,gamma,v,p1,p2,lambda,rho){

  gamma_delta_v=gamma+delta_m+v
  delta_update=SVS(gamma_delta_v,p1,p2,lambda/rho)
  return(delta_update)
}

#delta=delta_update;v=v_init
AD2_glm_FT=function(X,y,theta_P,delta,delta_m,v,n,p1,p2,alpha,rho){

  p12=p1*p2
  theta_delta=theta_P+delta_m
  A=matrix(0,p12,p12)
  B=matrix(0,p1,p2)

  for(i in 1:n){
    exp_eta=exp(sum(X[,,i]*(theta_delta)))
    A=A+exp_eta/(1+exp_eta)^2*c(X[,,i])%*%t(c(X[,,i]))
    B=B+(exp_eta/(1+exp_eta)-y[i])*X[,,i]
  }
  B=rho*(delta-delta_m-v)-alpha*B
  A=diag(rho,p12)+alpha*A

  inverse_try=try(solve(A),silent=TRUE)
  if(class(inverse_try)[1]=="try-error"){
    print("try-error")
    A_inverse=ginv(A)
  } else{
    A_inverse=inverse_try
  }
  gamma_update=matrix(A_inverse%*%c(B),p1,p2)
  return(gamma_update)
}

#delta_init=delta_ADMM_init;gamma_init=gamma_ADMM_init;v_init=v_ADMM_init
ADMM_glm_FT=function(X,y,theta_P,delta_init,delta_m,gamma_init,v_init,n,p1,p2,lambda,alpha,rho=1,tol_ADMM,maxit_ADMM){

  Loss_upper=c();l=1
  Loss_upper[l]=Loss_Sm_glm_FT(X,y,theta_P,delta_init,delta_m,gamma_init,v_init,n,p1,p2,lambda,alpha,rho)

  while(TRUE){
    delta_update=AD1_glm_FT(delta_m,gamma_init,v_init,p1,p2,lambda,rho)
    gamma_update=AD2_glm_FT(X,y,theta_P,delta_update,delta_m,v_init,n,p1,p2,alpha,rho)
    v_update=v_init+gamma_update-delta_update+delta_m

    Loss_upper[l+1]=Loss_Sm_glm_FT(X,y,theta_P,delta_update,delta_m,gamma_update,v_update,n,p1,p2,lambda,alpha,rho)

    if(l>maxit_ADMM){
      result=list()
      result$delta_update=delta_update
      result$gamma_update=gamma_update
      result$v_update=v_update
      result$Loss_ADMM=Loss_upper
      result$l=l
      return(result)
    }

    res=matrix(0,p1,p2)

    if(abs(Loss_upper[l+1]-Loss_upper[l])<tol_ADMM & SC_glm((gamma_update-delta_update+delta_m),res,tol=tol_ADMM)){
      result=list()
      result$delta_update=delta_update
      result$gamma_update=gamma_update
      result$v_update=v_update
      result$Loss_ADMM=Loss_upper
      result$l=l
      return(result)
    } else{
      delta_init=delta_update
      gamma_init=gamma_update
      v_init=v_update
      l=l+1
    }
  }
}

#theta_P=NULL;alpha=NULL;delta_init=NULL;tol_ADMM=1e-04;maxit_ADMM=3000;maxit_MM=10;tol_MM=0.1
glm_FT=function(X,y,theta_P=NULL,lambda,rho=1,alpha=NULL,delta_init=NULL,tol_ADMM=1e-04,maxit_ADMM=3000,tol_MM=0.1,maxit_MM=10){

  dimen=dim(X);p1=dimen[1];p2=dimen[2];n=dimen[3]
  if(is.null(theta_P)){
    theta_P=matrix(0,p1,p2)
  }

  if(is.null(alpha)){
    alpha=1/length(y)
  }

  if(is.null(delta_init)){
    delta_init=matrix(0,p1,p2)
  }

  delta_m=delta_init
  delta_ADMM_init=delta_init;gamma_ADMM_init=matrix(0,p1,p2)
  v_ADMM_init=matrix(0,p1,p2)

  m=1
  Loss_delta=c()

  result=list();resultfit=list()
  while(TRUE){

    #####
    fit=ADMM_glm_FT(X,y,theta_P,delta_ADMM_init,delta_m,gamma_ADMM_init,v_ADMM_init,n,p1,p2,lambda,alpha,rho,tol_ADMM,maxit_ADMM)
    delta_update=fit$delta_update

    Loss_delta[m]=sum((delta_update-delta_m)^2)
    resultfit[[m]]=fit

    if(m>maxit_MM){
      result$delta_update=delta_update
      #result$Loss_delta=Loss_delta
      #result$fit=resultfit
      result$m=m
      return(result)
    }

    if(m>3){
      if(Loss_delta[m]<tol_MM){
        result$delta_update=delta_update
        #result$Loss_delta=Loss_delta
        #result$fit=resultfit
        result$m=m
        return(result)
      } else{
        delta_m=delta_update
        m=m+1
        #print(m)
      }
    } else{
      delta_m=delta_update
      m=m+1
      #print(m)
    }
  }
}
