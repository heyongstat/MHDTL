SC=function(mu_update,mu_init,tol=0.001){

  mu_inl2=norm(mu_init,"F")
  if(mu_inl2==0){
    res=norm((mu_update-mu_init),"F")
  } else{
    res=norm((mu_update-mu_init),"F")/mu_inl2
  }
  return(res<=tol)
}


#theta=theta_init;delta=delta_init
Loss_S=function(X,y,theta,delta,K,nk,lambda1,lambda2,tau,beta){

  S=0
  for(k in 1:K){
    S=S+beta[k]*sum((y[[k]]-X[[k]]%*%theta[k,])^2)+lambda1*nk[k]*sum(abs(theta[k,]))
  }

  for(k in 1:(K-1)){
    S=S+lambda2*nk[k]*min(tau,sum(abs(delta[k,])))
  }
  return(S)
}

Loss_Sm=function(X,y,theta,delta,delta_m,v,K,nk,p,lambda1,lambda2,tau,beta,rho){

  Sm=0
  for(k in 1:K){
    Sm=Sm+beta[k]*sum((y[[k]]-X[[k]]%*%theta[k,])^2)+lambda1*nk[k]*sum(abs(theta[k,]))
  }

  for(k in 1:(K-1)){
    if(sum(abs(delta_m[k,]))<tau){
      Sm=Sm+lambda2*nk[k]*sum(abs(delta[k,]))
    } else{
      Sm=Sm+lambda2*nk[k]*tau
    }
  }

  de_th_v=delta-theta[1:(K-1),]+matrix(theta[K,],(K-1),p,byrow=TRUE)+v
  Sm=Sm+rho/2*(sum((de_th_v)^2)-sum((v)^2))
  return(Sm)
}

#theta=theta_init[K,];delta=delta_init;v=v_init
AD1=function(X,y,theta,delta,v,K,p,nk,lambda1,beta,rho){

  theta_hat=matrix(0,K-1,p)
  for(k in 1:(K-1)){
    X_star=rbind(sqrt(beta[k])*X[[k]],sqrt(rho/2)*diag(1,p))
    y_star1=sqrt(beta[k])*y[[k]]
    y_star2=as.matrix(sqrt(rho/2)*(delta[k,]+theta+v[k,]))
    y_star=rbind(y_star1,y_star2)
    theta_hat[k,]=as.matrix(glmnet(X_star,y_star,intercept=FALSE,lambda=lambda1*nk[k]/(nk[k]+p),eps=1)$beta)
  }
  return(theta_hat)
}

#X=X[[K]];y=y[[K]];theta=theta_update[-K,];delta=delta_init;v=v_init;beta=beta[K]
AD0=function(X,y,theta,delta,v,K,p,nk,lambda1,beta,rho){
  X_star1=sqrt(beta)*X
  X_star2=matrix(diag(-sqrt(rho/2),p),(K-1)*p,p,byrow=TRUE)
  X_star=rbind(X_star1,X_star2)

  y_star1=sqrt(beta)*y

  th_de_v=delta-theta+v
  y_star2=c(t(th_de_v))*sqrt(rho/2)
  y_star=c(y_star1,y_star2)

  theta_hat=as.matrix(glmnet(X_star,y_star,intercept=FALSE,lambda=lambda1*nk[K]/(nk[K]+(K-1)*p))$beta)
  return(theta_hat)
}

Prox=function(a,b){
  b_abs=abs(b)
  return((b_abs-a)*((b_abs-a)>0)*sign(b))
}

#theta=theta_update;v=v_init
AD2=function(theta,delta_m,v,K,nk,p,lambda2,tau,rho){

  delta_hat=delta_m
  th_v=theta[1:(K-1),]-matrix(theta[K,],(K-1),p,byrow=TRUE)-v

  for(k in 1:(K-1)){
    if(sum(abs(delta_m[k,]))<tau){
      delta_hat[k,]=Prox(lambda2*nk[k]/rho,th_v[k,])
    } else{
      delta_hat[k,]=th_v[k,]
    }
  }
  return(delta_hat)
}

#theta_init=theta_ADMM_init;delta_init=delta_ADMM_init;delta_m=delta_init;v_init=v_ADMM_init;
ADMM=function(X,y,theta_init,delta_init,delta_m,v_init,K,nk,p,lambda1,lambda2,tau,beta,rho,tol_ADMM,maxit_ADMM){
  theta_update=matrix(0,K,p)
  delta_update=v_update=theta_update[-K,]

  Loss_upper=c();l=1
  Loss_upper[l]=Loss_Sm(X,y,theta_init,delta_init,delta_m,v_init,K,nk,p,lambda1,lambda2,tau,beta,rho)

  while(TRUE){

    theta_update[-K,]=AD1(X,y,theta_init[K,],delta_init,v_init,K,p,nk,lambda1,beta[-K],rho)
    theta_update[K,]=AD0(X[[K]],y[[K]],theta_update[-K,],delta_init,v_init,K,p,nk,lambda1,beta[K],rho)
    delta_update=AD2(theta_update,delta_m,v_init,K,nk,p,lambda2,tau,rho)

    for(k in 1:(K-1)){
      v_update[k,]=v_init[k,]+delta_update[k,]-theta_update[k,]+theta_update[K,]
    }
    Loss_upper[l+1]=Loss_Sm(X,y,theta_update,delta_update,delta_m,v_update,K,nk,p,lambda1,lambda2,tau,beta,rho)

    if(l>maxit_ADMM){
      result=list()
      result$theta_update=theta_update
      result$delta_update=delta_update
      result$v_update=v_update
      result$Loss_ADMM=Loss_upper
      result$l=l
      return(result)
    }

    res=delta_update-theta_update[-K,]+matrix(theta_update[K,],K-1,p,byrow=TRUE)
    if(SC(theta_update,theta_init,tol=tol_ADMM) & SC(res,matrix(0,K-1,p),tol=tol_ADMM)){
      result=list()
      result$theta_update=theta_update
      result$delta_update=delta_update
      result$v_update=v_update
      result$Loss_ADMM=Loss_upper
      result$l=l
      return(result)
    } else{
      theta_init=theta_update
      delta_init=delta_update
      v_init=v_update
      l=l+1
    }
  }
}

TNPlm=function(X,y,lambda1,lambda2,tau,rho=1,beta=NULL,theta_init=NULL,tol_ADMM=0.0001,maxit_ADMM=3000,maxit_MM=10){

  dimen=sapply(X,dim)
  nk=dimen[1,];p=dimen[2,1];K=length(dimen[1,])

  if(class(beta)[1]=="NULL"){
    beta=rep(1,K)
  }

  if(class(theta_init)[1]=="NULL"){
    theta_init=matrix(0,K,p)
    for(k in 1:K){
      #lambda_opt=cv.glmnet(X[[k]],y[[k]],intercept=FALSE)
      theta_init[k,]=as.matrix(glmnet(X[[k]],y[[k]],intercept=FALSE,lambda=lambda1)$beta)
      #cl=makeCluster(10)
      #lambda_delta_SCAD=cv.ncvreg(X[[K]], y[[K]],cluster=cl,peanlty="SCAD",family="gaussian")
      #theta_init[k,] = ncvfit(X[[K]],y[[K]],penalty="SCAD",lambda=lambda_delta_SCAD$lambda.min)$beta
    }
  }

  delta_init=matrix(0,K-1,p)
  for(k in 1:(K-1)){
    delta_init[k,]=theta_init[k,]-theta_init[(K),]
  }

  theta_ADMM_init=theta_init;delta_ADMM_init=delta_init;v_ADMM_init=matrix(0,K-1,p)
  delta_m=delta_ADMM_init

  m=1
  Loss_orig=c()
  Loss_orig[m]=Loss_S(X,y,theta_init,delta_init,K,nk,lambda1,lambda2,tau,beta)

  result=list();
  #result$fit=list()
  while(TRUE){

    fit=ADMM(X,y,theta_ADMM_init,delta_ADMM_init,delta_m,v_ADMM_init,K,nk,p,lambda1,lambda2,tau,beta,rho,tol_ADMM,maxit_ADMM)
    theta_update=fit$theta_update;delta_update=fit$delta_update

    Loss_orig[m+1]=Loss_S(X,y,theta_update,delta_update,K,nk,lambda1,lambda2,tau,beta)
    #result$fit[[m]]=fit

    if(m>maxit_MM){
      result$theta_update=theta_update
      result$delta_update=delta_update
      #result$Loss=Loss_orig
      result$m=m
      return(result)
    }

    #print(m)
    if((Loss_orig[m+1]-Loss_orig[m])==0){
      result$theta_update=theta_update
      result$delta_update=delta_update
      #result$Loss=Loss_orig
      result$m=m
      return(result)
    } else{
      delta_m=delta_update
      m=m+1
    }
  }
}
